# Contributing Guidelines

Thank you for your interest in contributing!

- Fork the repository.
- Create a feature branch (`git checkout -b feature-name`)
- Commit your changes.
- Push to your branch.
- Open a pull request.

Please make sure your code is clean and well-commented.
