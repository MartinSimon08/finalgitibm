# Simple Interest Calculator

This is a simple bash script that calculates the simple interest based on principal, rate, and time entered by the user.

## How to Use

```bash
bash simple-interest.sh
```

Follow the prompts to enter the values. The script will output the simple interest calculated.
