# Code of Conduct

All participants are expected to behave respectfully and professionally. Harassment and abuse are not tolerated. Report issues to the repository maintainer.
